from django.apps import AppConfig


class MusicsConfig(AppConfig):
    name = 'musics'
