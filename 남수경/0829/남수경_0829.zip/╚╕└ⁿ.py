# import sys
# sys.stdin = open("회전_input.txt")
# T = int(input())
# for tc in range(T):
#     N,M = map(int, input().split()) #N개의 자연수 M번 돌리기
#     numbers = list(map(int,input().split()))
#
#     for i in range(M):
#         Top = numbers.pop(0)
#         numbers.append(Top)
#
#     print('#{} {}'.format(tc +1, numbers[0]))


x,y = (1,2)

print(x,y)